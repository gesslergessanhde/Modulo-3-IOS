//
//  LoginResponse.swift
//  APIAppUAMExample
//
//  Created by Macbook on 4/10/24.
//

import Foundation

struct LoginResponse: Decodable {
    let accessToken: String
}
