//
//  AddContactViewController.swift
//  Core_DataContactos
//
//  Created by User-UAM on 1/22/25.
//

//import UIKit
//
//class AddContactViewController: UIViewController {
//
//    let nameTextField = UITextField()
//    let phoneTextField = UITextField()
//    let emailTextField = UITextField()
//    let saveButton = UIButton()
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        view.backgroundColor = .white
//        title = "Agregar Contacto"
//
//        setupUI()
//    }
//
//    func setupUI() {
//        // Configuración de campos de texto
//        nameTextField.placeholder = "Nombre"
//        phoneTextField.placeholder = "Teléfono"
//        emailTextField.placeholder = "Correo Electrónico"
//
//        [nameTextField, phoneTextField, emailTextField].forEach { textField in
//            textField.borderStyle = .roundedRect
//            textField.translatesAutoresizingMaskIntoConstraints = false
//            view.addSubview(textField)
//        }
//
//        // Configuración del botón Guardar
//        saveButton.setTitle("Guardar", for: .normal)
//        saveButton.backgroundColor = .systemBlue
//        saveButton.layer.cornerRadius = 8
//        saveButton.translatesAutoresizingMaskIntoConstraints = false
//        saveButton.addTarget(self, action: #selector(saveContact), for: .touchUpInside)
//        view.addSubview(saveButton)
//
//        // Configuración de Constraints
//        NSLayoutConstraint.activate([
//            nameTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
//            nameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            nameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//
//            phoneTextField.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 15),
//            phoneTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            phoneTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//
//            emailTextField.topAnchor.constraint(equalTo: phoneTextField.bottomAnchor, constant: 15),
//            emailTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
//            emailTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
//
//            saveButton.topAnchor.constraint(equalTo: emailTextField.bottomAnchor, constant: 30),
//            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            saveButton.widthAnchor.constraint(equalToConstant: 100),
//            saveButton.heightAnchor.constraint(equalToConstant: 44)
//        ])
//    }
//
//    @objc func saveContact() {
//        // Aquí iría la lógica para guardar el contacto en Core Data.
//        navigationController?.popViewController(animated: true)
//    }
//}

import UIKit
import CoreData

protocol AddContactDelegate: AnyObject {
    func didAddContact()
}

class AddContactViewController: UIViewController {

    let nameTextField = UITextField()
    let phoneTextField = UITextField()
    let emailTextField = UITextField()
    let saveButton = UIButton()

    weak var delegate: AddContactDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Agregar Contacto"

        setupUI()
    }

    func setupUI() {
        // Configuración de campos de texto
        nameTextField.placeholder = "Nombre"
        phoneTextField.placeholder = "Teléfono"
        emailTextField.placeholder = "Correo Electrónico"

        [nameTextField, phoneTextField, emailTextField].forEach { textField in
            textField.borderStyle = .roundedRect
            textField.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(textField)
        }

        // Configuración del botón Guardar
        saveButton.setTitle("Guardar", for: .normal)
        saveButton.backgroundColor = .systemBlue
        saveButton.layer.cornerRadius = 8
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.addTarget(self, action: #selector(saveContact), for: .touchUpInside)
        view.addSubview(saveButton)

        // Configuración de Constraints
        NSLayoutConstraint.activate([
            nameTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            nameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            nameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            phoneTextField.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 15),
            phoneTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            phoneTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            emailTextField.topAnchor.constraint(equalTo: phoneTextField.bottomAnchor, constant: 15),
            emailTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            emailTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            saveButton.topAnchor.constraint(equalTo: emailTextField.bottomAnchor, constant: 30),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            saveButton.widthAnchor.constraint(equalToConstant: 100),
            saveButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    @objc func saveContact() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        let newContact = Contacto(context: context)
        newContact.nombre = nameTextField.text
        newContact.telefono = phoneTextField.text
        newContact.correo = emailTextField.text

        do {
            try context.save()
            delegate?.didAddContact()
            navigationController?.popViewController(animated: true)
        } catch {
            print("Error al guardar contacto: \(error)")
        }
    }
}
