//
//  ViewController.swift
//  Core_DataContactos
//
//  Created by User-UAM on 1/22/25.
//

//
//  ViewController.swift
//  Core data(Contactos)
//
//  Created by User-UAM on 1/22/25.
//

//import UIKit
//import CoreData
//class ViewController: UIViewController {
//
//    let tableView = UITableView()
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        view.backgroundColor = .white
//        title = "Libreta de Direcciones"
//
//        setupTableView()
//        setupNavigationBar()
//    }
//
//    func setupTableView() {
//        tableView.frame = view.bounds
//        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
//        view.addSubview(tableView)
//    }
//
//    func setupNavigationBar() {
//        navigationItem.rightBarButtonItem = UIBarButtonItem(
//            barButtonSystemItem: .add,
//            target: self,
//            action: #selector(addContact)
//        )
//    }
//
//    @objc func addContact() {
//        let addContactVC = AddContactViewController()
//        navigationController?.pushViewController(addContactVC, animated: true)
//    }
//}

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as? ContactCell else {
                return UITableViewCell()
            }

            let contact = contacts[indexPath.row]
            cell.configure(with: contact)
            return cell
        }


    let tableView = UITableView()
    var contacts: [Contacto] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Libreta de Direcciones"

        setupTableView()
        setupNavigationBar()
        fetchContacts()
    }

    func setupTableView() {
        tableView.frame = view.bounds
        tableView.register(ContactCell.self, forCellReuseIdentifier: "ContactCell")
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
    }

    func setupNavigationBar() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addContact)
        )
    }

    @objc func addContact() {
        let addContactVC = AddContactViewController()
        addContactVC.delegate = self
        navigationController?.pushViewController(addContactVC, animated: true)
    }

    func fetchContacts() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<Contacto> = Contacto.fetchRequest()

        do {
            contacts = try context.fetch(fetchRequest)
            tableView.reloadData()
        } catch {
            print("Error al obtener contactos: \(error)")
        }
    }

    // MARK: - UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
}


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }


extension ViewController: AddContactDelegate {
    func didAddContact() {
        fetchContacts()
    }
}
